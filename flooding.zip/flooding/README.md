# WebSocketClientExample
Example of a websocket client written in Java
It implements the Websocket.Listener interface for communicating over WebSocket protocol.
It uses GSON deserializer for handling JSON messages.
## Installation GSON
- `CTL+ALT+SHIFT+S` (Windows) to open the project structure dialog.
- Select `Libraries` from the left pane.
- Click the `+` button to add a new library.
- Select `From Maven` from the dropdown.
- Search for `com.google.code.gson` and select the latest version.
- Click `Apply` to add the library to the project.
